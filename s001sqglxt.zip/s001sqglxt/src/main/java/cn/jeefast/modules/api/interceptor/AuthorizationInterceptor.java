package cn.jeefast.modules.api.interceptor;


import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import cn.jeefast.common.exception.RRException;
import cn.jeefast.modules.api.annotation.AuthIgnore;
import cn.jeefast.modules.api.entity.TbToken;
import cn.jeefast.modules.api.service.TbTokenService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 权限(Token)验证
 */
@Component
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    private TbTokenService tokenService;

    public static final String USER_KEY = "userId";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        AuthIgnore annotation;
        if(handler instanceof HandlerMethod) {
            annotation = ((HandlerMethod) handler).getMethodAnnotation(AuthIgnore.class);
        }else{
            return true;
        }

        //如果有@IgnoreAuth注解，则No验证token
        if(annotation != null){
            return true;
        }

        //从header中obtain token
        String token = request.getHeader("token");
        //如果header中No存在token，则从参数中obtain token
        if(StringUtils.isBlank(token)){
            token = request.getParameter("token");
        }

        //token为空
        if(StringUtils.isBlank(token)){
            throw new RRException("tokenNo能为空");
        }

        //querytoken信息
        TbToken tokenEntity = tokenService.queryByToken(token);
        if(tokenEntity == null || tokenEntity.getExpireTime().getTime() < System.currentTimeMillis()){
            throw new RRException("token失效，请重新login");
        }

        //设置userId到request里，后续根据userId，obtain user信息
        request.setAttribute(USER_KEY, tokenEntity.getUserId());

        return true;
    }
}
