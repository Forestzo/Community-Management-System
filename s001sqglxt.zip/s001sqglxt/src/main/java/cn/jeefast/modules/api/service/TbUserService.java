package cn.jeefast.modules.api.service;

import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.modules.api.entity.TbUser;

/**
 * <p>
 * user service类
 * </p>
 *
 */
public interface TbUserService extends IService<TbUser> {
	
	TbUser queryByMobile(String mobile);
	
	void deleteBatch(Long[] userIds);

	/**
	 * User login
	 * @param mobile    mobile
	 * @param password  password
	 * @return          returnuserID
	 */
	long login(String mobile, String password);

	void save(String mobile, String password);
	
}
