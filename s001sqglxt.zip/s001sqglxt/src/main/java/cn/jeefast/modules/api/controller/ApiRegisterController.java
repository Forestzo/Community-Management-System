package cn.jeefast.modules.api.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.Assert;
import cn.jeefast.modules.api.annotation.AuthIgnore;
import cn.jeefast.modules.api.service.TbUserService;

/**
 * register
 */
@RestController
@RequestMapping("/api")
public class ApiRegisterController {
    @Autowired
    private TbUserService userService;

    /**
     * register
     */
    @AuthIgnore
    @PostMapping("register")
    public R register(String mobile, String password){
        Assert.isBlank(mobile, "mobileNo能为空");
        Assert.isBlank(password, "passwordNo能为空");

        userService.save(mobile, password);

        return R.ok();
    }
}
