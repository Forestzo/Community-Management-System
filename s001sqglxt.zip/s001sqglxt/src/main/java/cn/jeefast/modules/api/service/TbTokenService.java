package cn.jeefast.modules.api.service;

import java.util.Map;

import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.modules.api.entity.TbToken;

/**
 * <p>
 * userToken service类
 * </p>
 *
 */
public interface TbTokenService extends IService<TbToken> {
	
	TbToken queryByUserId(Long userId);

	TbToken queryByToken(String token);
	
	/**
	 * 生成token
	 * @param userId  userID
	 * @return        returntoken相关信息
	 */
	Map<String, Object> createToken(long userId);
	
}
