package cn.jeefast.modules.api.service.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import cn.jeefast.common.exception.RRException;
import cn.jeefast.common.validator.Assert;
import cn.jeefast.modules.api.dao.TbUserDao;
import cn.jeefast.modules.api.entity.TbUser;
import cn.jeefast.modules.api.service.TbUserService;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * user service实现类
 * </p>
 *
 */
@Service
public class TbUserServiceImpl extends ServiceImpl<TbUserDao, TbUser> implements TbUserService {

	@Autowired
	private TbUserDao userDao;
	
	@Override
	public TbUser queryByMobile(String mobile) {
		return userDao.queryByMobile(mobile);
	}

	@Override
	public void deleteBatch(Long[] userIds) {
		List<Long> idsList = Arrays.stream(userIds).collect(Collectors.toList());  
		userDao.deleteBatchIds(idsList);
	}

	@Override
	public long login(String mobile, String password) {
		TbUser user = queryByMobile(mobile);
		Assert.isNull(user, "mobile或password错误");

		//password错误
		if(!user.getPassword().equals(DigestUtils.sha256Hex(password))){
			throw new RRException("mobile或password错误");
		}

		return user.getUserId();
	}

	@Override
	public void save(String mobile, String password) {
		TbUser user = new TbUser();
		user.setMobile(mobile);
		user.setUsername(mobile);
		user.setPassword(DigestUtils.sha256Hex(password));
		user.setCreateTime(new Date());
		userDao.insert(user);
	}
	
}
