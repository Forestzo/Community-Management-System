package cn.jeefast.datasources;

/**
 * 增加多数据源，在此配置
 *
 */
public interface DataSourceNames {
    String FIRST = "first";
    String SECOND = "second";

}
