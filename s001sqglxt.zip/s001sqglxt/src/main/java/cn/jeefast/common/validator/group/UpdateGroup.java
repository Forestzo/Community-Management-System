package cn.jeefast.common.validator.group;

/**
 * 更新数据 Group
 */

public interface UpdateGroup {

}
