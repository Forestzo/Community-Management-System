package cn.jeefast.common.validator.group;

/**
 * add数据 Group
 */
public interface AddGroup {
}
