package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysCarposition;
import cn.jeefast.system.service.SysCarpositionService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * Parking space management
 * </p>
 *
 */
@RestController
@RequestMapping("/sysCarposition")
public class SysCarpositionController extends BaseController {

    @Autowired
    private SysCarpositionService sysCarpositionService;

    /**
     * Query Parking Data
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:carposition:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //Query the data of the list
        Query query = new Query(params);
        Page<SysCarposition> pageUtil = new Page<SysCarposition>(query.getPage(), query.getLimit());
        Page<SysCarposition> page = sysCarpositionService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Parking space information
     */
    @RequestMapping("/info/{carpositionId}")
    @RequiresPermissions("sys:carposition:info")
    public R info(@PathVariable("carpositionId") String carpositionId) {
        SysCarposition carposition = sysCarpositionService.selectById(carpositionId);
        return R.ok().put("carposition", carposition);
    }

    /**
     * Store information of Parking space management
     */
    @Log("Parking space management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:carposition:save")
    public R save(@RequestBody SysCarposition carposition) {
        ValidatorUtils.validateEntity(carposition);
        carposition.setCreatetime(new Date());
        carposition.setCreateuser(getUser().getUsername());
        carposition.setUpdateime(new Date());
        carposition.setUpdateuser(getUser().getUsername());
        sysCarpositionService.insert(carposition);
        return R.ok();
    }

    /**
     * Update Parking data
     */
    @Log("updateParking space management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:carposition:update")
    public R update(@RequestBody SysCarposition carposition) {
        ValidatorUtils.validateEntity(carposition);
        carposition.setUpdateime(new Date());
        carposition.setUpdateuser(getUser().getUsername());
        sysCarpositionService.updateById(carposition);
        return R.ok();
    }

    /**
     * deleteParking space management
     */
    @Log("deleteParking space management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:carposition:delete")
    public R delete(@RequestBody String[] carpositionIds) {
        sysCarpositionService.deleteBatch(carpositionIds);
        return R.ok();
    }
}
