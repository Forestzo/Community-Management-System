package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.entity.SysChargeinfo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * Charging record management Mapper 接口
 * </p>
 *
 */
public interface SysChargeinfoDao extends BaseMapper<SysChargeinfo> {
    List<SysChargeinfo> queryPageList(Page<SysChargeinfo> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}