package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.entity.SysMaintain;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * 公共申请service Mapper 接口
 * </p>
 *
 */
public interface SysApplayinfoDao extends BaseMapper<SysApplayinfo> {
    List<SysApplayinfo> queryPageList(Page<SysApplayinfo> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}