package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.entity.SysChargeinfo;
import cn.jeefast.system.service.SysChargeService;
import cn.jeefast.system.service.SysChargeinfoService;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Charging management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysCharge")
public class SysChargeController extends BaseController {

    @Autowired
    private SysChargeService sysChargeService;

    @Autowired
    private SysChargeinfoService sysChargeinfoService;

    /**
     * Charging management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:charge:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysCharge> pageUtil = new Page<SysCharge>(query.getPage(), query.getLimit());
        Page<SysCharge> page = sysChargeService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Charging management信息
     */
    @RequestMapping("/info/{chargeId}")
    @RequiresPermissions("sys:charge:info")
    public R info(@PathVariable("chargeId") String chargeId) {
        SysCharge charge = sysChargeService.selectById(chargeId);
        return R.ok().put("charge", charge);
    }

    /**
     * 保存Charging management
     */
    @Log("保存Charging management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:charge:save")
    public R save(@RequestBody SysCharge charge) {
        ValidatorUtils.validateEntity(charge);
        SysChargeinfo sysChargeinfo = new SysChargeinfo();
        SysCharge oldCharge = sysChargeService.selectOne(new EntityWrapper<SysCharge>().eq("username",charge.getUsername()).eq("type",charge.getType()));
        if(oldCharge != null){
            oldCharge.setMoney(oldCharge.getMoney()+charge.getMoney());
            oldCharge.setUpdateime(new Date());
            oldCharge.setUpdateuser(getUser().getUsername());
            sysChargeService.updateById(oldCharge);
            sysChargeinfo.setCreatetime(new Date());
            sysChargeinfo.setCreateuser(getUser().getUsername());
            sysChargeinfo.setUpdateime(new Date());
            sysChargeinfo.setUpdateuser(getUser().getUsername());
            sysChargeinfo.setCost(charge.getMoney());
            sysChargeinfo.setUsername(oldCharge.getUsername());
            sysChargeinfo.setChargeid(oldCharge.getId());
            sysChargeinfo.setDeptid(oldCharge.getDeptid());
            sysChargeinfoService.insert(sysChargeinfo);

        }else{
            charge.setCreatetime(new Date());
            charge.setCreateuser(getUser().getUsername());
            charge.setUpdateime(new Date());
            charge.setUpdateuser(getUser().getUsername());
            sysChargeService.insert(charge);
            sysChargeinfo.setCreatetime(new Date());
            sysChargeinfo.setCreateuser(getUser().getUsername());
            sysChargeinfo.setUpdateime(new Date());
            sysChargeinfo.setUpdateuser(getUser().getUsername());
            sysChargeinfo.setCost(charge.getMoney());
            sysChargeinfo.setUsername(charge.getUsername());
            sysChargeinfo.setChargeid(charge.getId());
            sysChargeinfo.setDeptid(charge.getDeptid());
            sysChargeinfoService.insert(sysChargeinfo);
        }

        return R.ok();
    }

    /**
     * updateCharging management
     */
    @Log("updateCharging management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:charge:update")
    public R update(@RequestBody SysCharge charge) {
        ValidatorUtils.validateEntity(charge);
        charge.setUpdateime(new Date());
        charge.setUpdateuser(getUser().getUsername());
        sysChargeService.updateById(charge);
        return R.ok();
    }

    /**
     * deleteCharging management
     */
    @Log("deleteCharging management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:charge:delete")
    public R delete(@RequestBody String[] chargeIds) {
        if(chargeIds.length>0){
            for(int i =0;i<chargeIds.length;i++){
                sysChargeinfoService.delete(new EntityWrapper<SysChargeinfo>().eq("chargeid",chargeIds[i]));
            }
        }
        sysChargeService.deleteBatch(chargeIds);
        return R.ok();
    }
}
