package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.entity.SysMaintain;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Maintenance management service类
 * </p>
 *
 */
public interface SysMaintainService extends IService<SysMaintain> {
    Page<SysMaintain> queryPageList(Page<SysMaintain> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
