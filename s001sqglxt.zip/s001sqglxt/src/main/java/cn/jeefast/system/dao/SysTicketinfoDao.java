package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysTicket;
import cn.jeefast.system.entity.SysTicketinfo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * Voting optionmanagement Mapper 接口
 * </p>
 *
 */
public interface SysTicketinfoDao extends BaseMapper<SysTicketinfo> {
    List<SysTicketinfo> queryPageList(Page<SysTicketinfo> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}