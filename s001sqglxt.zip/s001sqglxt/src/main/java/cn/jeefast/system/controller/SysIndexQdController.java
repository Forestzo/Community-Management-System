package cn.jeefast.system.controller;


import cn.jeefast.common.base.BaseController;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.Assert;
import cn.jeefast.system.entity.*;
import cn.jeefast.system.service.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysIndexQd")
public class SysIndexQdController extends BaseController {

    @Value("${server.port}")
    private String serverport;

    @Value("${server.context-path}")
    private String servercontextpath;


    @Autowired
    private SysUserTokenService sysUserTokenService;

    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private TMaterialFileService tMaterialFileService;

    @Autowired
    private SysChargeService sysChargeService;

    @Autowired
    private SysChargeinfoService sysChargeinfoService;

    @Autowired
    private SysDeptService sysDeptService;

    @Autowired
    private SysMaintainService sysMaintainService;

    @Autowired
    private SysPublicserviceService sysPublicserviceService;

    @Autowired
    private SysApplayinfoService sysApplayinfoService;

    @Autowired
    private SysServiceadmService sysServiceadmService;

    @Autowired
    private SysTicketService sysTicketService;

    @Autowired
    private SysTicketinfoService sysTicketinfoService;

//    @Autowired
//    private SysCjfgnService sysCjfgnService;
//
//    @Autowired
//    private SysZhanghuService sysZhanghuService;
//
//    @Autowired
//    private SysTrqjgglService sysTrqjgglService;
//
//    @Autowired
//    private SysJfgnglService sysJfgnglService;




    /**
     * obtain user信息
     */
    @RequestMapping("/getUser")
    public R getUser(@RequestBody Map<String,Object> tjarray){
        System.out.println("tjarraytjarray"+tjarray);

        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",tjarray.get("token")+""));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
        System.out.println("useruseruseruser"+user);
        return R.ok().put("sysuser",user);

    }



    /**
     * personal information更新
     */
    @RequestMapping("/updateuser")
    public R updateuser(@RequestBody SysUser sysUser){
        System.out.println("sysUsersysUser"+sysUser);
        sysUserService.updateById(sysUser);
        return R.ok();

    }

    /**
     * 个人更改password
     */
    @RequestMapping("/updaterealname")
    public R updaterealname(@RequestBody JSONObject tjarray) {
        String token = tjarray.getString("token");
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token", token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
        String realname = tjarray.getString("realname");
        System.out.println("realnamerealnamerealname"+realname);
        user.setRealname(realname);
        System.out.println("useruseruser"+user);
        System.out.println("getRealnamegetRealname"+user.getRealname());
        sysUserService.updateById(user);
        return R.ok().put("sysuser",user);
    }

    /**
     * 个人更改password
     */
    @RequestMapping("/updatepassword")
    public R updatepassword(@RequestBody JSONObject tjarray){
        String token = tjarray.getString("token");
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());


        String oldpassword = tjarray.getString("oldpassword");
        String newPassword =  tjarray.getString("password");


        Assert.isBlank(newPassword, "新passwordNo为能空");

        //sha256加密
        oldpassword = new Sha256Hash(oldpassword, user.getSalt()).toHex();
        //sha256加密
        newPassword = new Sha256Hash(newPassword, user.getSalt()).toHex();
        if(!oldpassword.equals(user.getPassword())){
            return R.error("原passwordNo正确无法updatepassword");
        }

//        SysUser user = new SysUser();
        user.setUserId(user.getUserId());
        user.setPassword(newPassword);
        //更新password
        sysUserService.updateById(user);
        return R.ok();

    }

    /**
     * 缴费功能列表query
     */
    @RequestMapping("/getCjfgnListAll")
    public R getCjfgnListAll(@RequestBody Map<String,Object> tjarray){
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
//        Map<String, Object> map = new HashMap<>();
//        map.put("username",user.getUsername());
        List<SysCharge> sysCjfgns = sysChargeService.selectList(new EntityWrapper<SysCharge>().eq("username",user.getUsername()));
        if(sysCjfgns.size()>0){
            for(int i=0;i<sysCjfgns.size();i++){
                SysCharge sysCharge = sysCjfgns.get(i);
                SysDept sysDept = sysDeptService.selectById(sysCharge.getDeptid());
                if(sysDept != null){
                    sysCharge.setDeptName(sysDept.getName());
                }
                if(sysCharge.getType() != null){
                    if(sysCharge.getType().equals("1")){
                        sysCharge.setTypeName("electricity fees");
                    }else if(sysCharge.getType().equals("2")){
                        sysCharge.setTypeName("charge for water");
                    }else if(sysCharge.getType().equals("3")){
                        sysCharge.setTypeName("Rental fee");
                    }else if(sysCharge.getType().equals("4")){
                        sysCharge.setTypeName("Property fee");
                    }else{
                        sysCharge.setTypeName("other");
                    }
                }
            }
        }

        System.out.println("sysCjfgnssysCjfgnssysCjfgns"+sysCjfgns);
        return R.ok().put("cjfgnList",sysCjfgns);
    }

    /**
     * obtain service列表
     */
    @RequestMapping("/getserviceadmListAll")
    public R getserviceadmListAll(@RequestBody JSONObject tjarray){
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
        String fl = tjarray.getString("fl");
        List<SysServiceadm> serviceadmList = sysServiceadmService.selectList(new EntityWrapper<SysServiceadm>().eq("fl",fl).eq("username",user.getUsername()));
        if(serviceadmList.size()>0){
            for(int i=0;i<serviceadmList.size();i++){
                SysServiceadm sysServiceadm = serviceadmList.get(i);
                SysDept sysDept = sysDeptService.selectById(sysServiceadm.getDeptid());
                if(sysDept != null){
                    sysServiceadm.setDeptName(sysDept.getName());
                }
                if(sysServiceadm.getFl()!= null){
                    if(sysServiceadm.getFl().equals("1")){
                        sysServiceadm.setFlName("Parcel query");
                    }else if(sysServiceadm.getFl().equals("2")){
                        sysServiceadm.setFlName("Home delivery");
                    }
                }
            }
        }
        return R.ok().put("serviceadmList",serviceadmList);
    }

    /**
     * 全部投票
     */
    @RequestMapping("/getticktListAll")
    public R getticktListAll(@RequestBody JSONObject tjarray){
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());

        List<SysTicket> ticktList = sysTicketService.selectList(new EntityWrapper<SysTicket>().eq("deptid",user.getDeptId()+""));
        if(ticktList.size()>0){
            for(int i=0;i<ticktList.size();i++){
                SysTicket sysTicket = ticktList.get(i);
                SysDept sysDept = sysDeptService.selectById(sysTicket.getDeptid());
                if(sysDept != null){
                    sysTicket.setDeptName(sysDept.getName());
                }
            }
        }
        return R.ok().put("ticktList",ticktList);
    }

    /**
     * 缴费功能详细列表query
     */
    @RequestMapping("/getrecordInfoListAll")
    public R getrecordInfoListAll(@RequestBody JSONObject tjarray){
        String chargeid = tjarray.getString("id");
        String type = tjarray.getString("type");
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
//        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
//        Map<String, Object> map = new HashMap<>();
//        map.put("username",user.getUsername());
        List<SysChargeinfo> recordInfoList = sysChargeinfoService.selectList(new EntityWrapper<SysChargeinfo>().eq("chargeid",chargeid).eq("type",type));
        if(recordInfoList.size()>0){
            for(int i=0;i<recordInfoList.size();i++){
                SysChargeinfo sysChargeinfo = recordInfoList.get(i);
                SysDept sysDept = sysDeptService.selectById(sysChargeinfo.getDeptid());
                if(sysDept != null){
                    sysChargeinfo.setDeptName(sysDept.getName());
                }
                if(sysChargeinfo.getType() != null){
                    if(sysChargeinfo.getType().equals("1")){
                        sysChargeinfo.setTypeName("electricity fees");
                    }else if(sysChargeinfo.getType().equals("2")){
                        sysChargeinfo.setTypeName("charge for water");
                    }else if(sysChargeinfo.getType().equals("3")){
                        sysChargeinfo.setTypeName("Rental fee");
                    }else if(sysChargeinfo.getType().equals("4")){
                        sysChargeinfo.setTypeName("Property fee");
                    }else{
                        sysChargeinfo.setTypeName("other");
                    }
                }
            }
        }
        System.out.println("recordInfoListrecordInfoListrecordInfoList"+recordInfoList);
        return R.ok().put("recordInfoList",recordInfoList);
    }

    /**
     * 支付功能
     */
    @RequestMapping("/zhifu")
    public R zhifu(@RequestBody JSONObject tjarray){
        Double cost = tjarray.getDouble("cost");
        String type = tjarray.getString("type");
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());

        SysCharge charge = new SysCharge();
        SysCharge oldCharge = sysChargeService.selectOne(new EntityWrapper<SysCharge>().eq("username",user.getUsername()).eq("type",type));


        SysChargeinfo sysChargeinfo = new SysChargeinfo();
        if(oldCharge != null){
//            oldCharge.setType(type);
            oldCharge.setMoney(oldCharge.getMoney()+cost);
            oldCharge.setUpdateime(new Date());
            oldCharge.setUpdateuser(user.getUsername());
            sysChargeService.updateById(oldCharge);
            sysChargeinfo.setType(oldCharge.getType());
            sysChargeinfo.setCreatetime(new Date());
            sysChargeinfo.setCreateuser(user.getUsername());
            sysChargeinfo.setUpdateime(new Date());
            sysChargeinfo.setUpdateuser(user.getUsername());
            sysChargeinfo.setCost(cost);
            sysChargeinfo.setUsername(oldCharge.getUsername());
            sysChargeinfo.setChargeid(oldCharge.getId());
            sysChargeinfo.setDeptid(oldCharge.getDeptid());
            sysChargeinfoService.insert(sysChargeinfo);

        }else{
            charge.setMoney(cost);
            charge.setDeptid(user.getDeptId()+"");
            charge.setType(type);
            charge.setUsername(user.getUsername());
            charge.setCreatetime(new Date());
            charge.setCreateuser(user.getUsername());
            charge.setUpdateime(new Date());
            charge.setUpdateuser(user.getUsername());
            sysChargeService.insert(charge);

            sysChargeinfo.setType(type);
            sysChargeinfo.setCreatetime(new Date());
            sysChargeinfo.setCreateuser(user.getUsername());
            sysChargeinfo.setUpdateime(new Date());
            sysChargeinfo.setUpdateuser(user.getUsername());
            sysChargeinfo.setCost(charge.getMoney());
            sysChargeinfo.setUsername(charge.getUsername());
            sysChargeinfo.setChargeid(charge.getId());
            sysChargeinfo.setDeptid(charge.getDeptid());
            sysChargeinfoService.insert(sysChargeinfo);
        }
//        Map<String, Object> map = new HashMap<>();
//        map.put("username",user.getUsername());
//        List<SysChargeinfo> recordInfoList = sysChargeinfoService.selectList(new EntityWrapper<SysChargeinfo>().eq("chargeid",chargeid).eq("type",type));
//        System.out.println("recordInfoListrecordInfoListrecordInfoList"+recordInfoList);
        return R.ok();
    }

    /**
     * 投票option
     */
    @RequestMapping("/savetickt")
    public R savetickt(@RequestBody JSONObject tjarray) {
        String token = tjarray.get("token") + "";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token", token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
        String ticktid = tjarray.getString("ticktid");
        String type = tjarray.getString("type");

        SysTicket sysTicket = sysTicketService.selectById(ticktid);

        List<SysTicketinfo> oldSysTicketinfo = sysTicketinfoService.selectList(new EntityWrapper<SysTicketinfo>().eq("username",user.getUsername()).eq("ticketid",sysTicket.getId()));
        if(oldSysTicketinfo.size()>0){
            return R.error("你已经参与过该事项的投票，请勿重复投票！");
        }else{
            SysTicketinfo sysTicketinfo = new SysTicketinfo();
            sysTicketinfo.setCreatetime(new Date());
            sysTicketinfo.setCreateuser(user.getUsername());
            sysTicketinfo.setUpdateime(new Date());
            sysTicketinfo.setUpdateuser(user.getUsername());
            sysTicketinfo.setName(sysTicket.getName());
            sysTicketinfo.setContent(sysTicket.getContent());
            sysTicketinfo.setDeptid(sysTicket.getDeptid());

            sysTicketinfo.setUsername(user.getUsername());
            sysTicketinfo.setType(type);
            sysTicketinfo.setTicketid(sysTicket.getId());
            sysTicketinfoService.insert(sysTicketinfo);
            return R.ok();
        }
    }

    /**
     * Submit设备Maintenance
     */
    @RequestMapping("/saveMaintain")
    public R saveMaintain(@RequestBody JSONObject tjarray){
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());

        String name = tjarray.getString("name");
        String content = tjarray.getString("content");
        String type = tjarray.getString("type");


        SysMaintain sysMaintain = new SysMaintain();
        sysMaintain.setName(name);
        sysMaintain.setContent(content);
        sysMaintain.setType(type);
        sysMaintain.setDeptid(user.getDeptId()+"");

        sysMaintain.setCreatetime(new Date());
        sysMaintain.setCreateuser(user.getUsername());
        sysMaintain.setUpdateime(new Date());
        sysMaintain.setUpdateuser(user.getUsername());
        sysMaintainService.insert(sysMaintain);
        return R.ok();

    }

    /**
     * shopping
     */
    @RequestMapping("/saveServiceadmup")
    public R saveServiceadmup(@RequestBody JSONObject tjarray) {
        System.out.println("tjarraytjarraytjarraytjarray" + JSON.toJSONString(tjarray));
        String name = tjarray.getString("name");
        String content = tjarray.getString("content");
        String token = tjarray.get("token") + "";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token", token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());

        SysServiceadm serviceadm = new SysServiceadm();
        serviceadm.setCreatetime(new Date());
        serviceadm.setCreateuser(user.getUsername());
        serviceadm.setUpdateime(new Date());
        serviceadm.setUpdateuser(user.getUsername());

        serviceadm.setName(name);
        serviceadm.setContent(content);
        serviceadm.setType("2");
        serviceadm.setDeptid(user.getDeptId()+"");
        serviceadm.setFl("2");
        serviceadm.setUsername(user.getUsername());
        sysServiceadmService.insert(serviceadm);
        return R.ok();

    }

    /**
     * 申请公共设施
     */
    @RequestMapping("/saveApplayinfo")
    public R saveApplayinfo(@RequestBody JSONObject tjarray) throws ParseException {
        System.out.println("tjarraytjarraytjarraytjarray"+JSON.toJSONString(tjarray));
        String token = tjarray.get("token")+"";
        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
        SysUser user = sysUserService.selectById(sysUserToken.getUserId());

        String name = tjarray.getString("name");
        String content = tjarray.getString("content");
        String publicservice = tjarray.getString("publicservice");
        String sqsj = tjarray.getString("sqsj").substring(0,10);
        sqsj = sqsj+" 00:00:00";
        List<SysApplayinfo> oldSysApplayinfos = sysApplayinfoService.selectList(new EntityWrapper<SysApplayinfo>().eq("sqsj",sqsj).eq("publicserviceid",publicservice));
        if(oldSysApplayinfos.size()>0){
            return R.error("该公共区域设施已被申请无法重复申请！");
        }else{
            SysApplayinfo sysApplayinfo = new SysApplayinfo();
            sysApplayinfo.setCreatetime(new Date());
            sysApplayinfo.setCreateuser(user.getUsername());
            sysApplayinfo.setUpdateime(new Date());
            sysApplayinfo.setUpdateuser(user.getUsername());


            sysApplayinfo.setPublicserviceid(publicservice);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            sysApplayinfo.setDeptid(user.getDeptId()+"");
            sysApplayinfo.setName(name);
            sysApplayinfo.setContent(content);
            sysApplayinfo.setSqsj(sdf.parse(sqsj));
            sysApplayinfoService.insert(sysApplayinfo);
            return R.ok();
        }
    }



    /**
     * obtain 公共设施
     */
    @RequestMapping("/getPublicservices")
    public R getPublicservices(@RequestBody JSONObject tjarray){
        List<SysPublicservice> publicservices = sysPublicserviceService.selectList(new EntityWrapper<>());
        return R.ok().put("publicservices",publicservices);
    }


//    /**
//     * obtain 商品信息
//     */
//    @RequestMapping("/getCjfgnInfo")
//    public R getCjfgnInfo(@RequestBody Map<String,Object> tjarray) throws UnknownHostException {
//        System.out.println("tjarraytjarraytjarray" + tjarray);
//        if (tjarray.get("id") == null) {
//            return R.error("Please select要查看的 content");
//        }
//        String id = tjarray.get("id") + "";
//        SysCjfgn sysCjfgn = sysCjfgnService.selectById(id);
//        return R.ok().put("cjfgn",sysCjfgn);
//    }
//
//    /**
//     * 我的账户信息query
//     */
//    @RequestMapping("/getZhanghuListAll")
//    public R getZhanghuListAll(@RequestBody Map<String,Object> tjarray){
//        String token = tjarray.get("token")+"";
//        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
//        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
//        List<SysZhanghu> sysZhanghus = sysZhanghuService.selectList(new EntityWrapper<SysZhanghu>().eq("username",user.getUsername()));
//        if(sysZhanghus.size()>0){
//            for(int i=0;i<sysZhanghus.size();i++){
//                SysZhanghu sysZhanghu = sysZhanghus.get(i);
//                sysZhanghu = getFjSysZhanghu(sysZhanghu);
//            }
//        }
//        return R.ok().put("zhanghuList",sysZhanghus);
//    }
//
//    /**
//     * 天然气Pricequery
//     */
//    @RequestMapping("/gettrqjgListAll")
//    public R gettrqjgListAll(@RequestBody Map<String,Object> tjarray){
//        String token = tjarray.get("token")+"";
//        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
//        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
//        List<SysTrqjggl> trqjgList = sysTrqjgglService.selectList(new EntityWrapper<SysTrqjggl>().orderBy(true,"updatetime",false));
//        return R.ok().put("trqjgList",trqjgList);
//    }
//
//    /**
//     * 我的缴费记录query
//     */
//    @RequestMapping("/getjfgnglListAll")
//    public R getjfgnglListAll(@RequestBody Map<String,Object> tjarray){
//        String token = tjarray.get("token")+"";
//        SysUserToken sysUserToken = sysUserTokenService.selectOne(new EntityWrapper<SysUserToken>().eq("token",token));
//        SysUser user = sysUserService.selectById(sysUserToken.getUserId());
//        List<SysJfgngl> jfgnglList = sysJfgnglService.selectList(new EntityWrapper<SysJfgngl>().orderBy(true,"updatetime",false));
//        if(jfgnglList.size()>0){
//            for(int i=0;i<jfgnglList.size();i++){
//                SysJfgngl sysJfgngl = jfgnglList.get(i);
//                SysZhanghu sysZhanghu = sysZhanghuService.selectById(sysJfgngl.getZhanghuid());
//                sysJfgngl.setZhanghu(sysZhanghu.getZhanghu());
//                sysJfgngl.setUsername(sysZhanghu.getUsername());
//            }
//        }
//        return R.ok().put("jfgnglList",jfgnglList);
//    }
//
//
//
//    public SysZhanghu getFjSysZhanghu(SysZhanghu sysZhanghu) {
//        if(sysZhanghu.getTzgl() != null){//发源地type
//            String value = sysZhanghu.getTzgl();
//            if(value.equals("1")){
//                sysZhanghu.setTzglname("跳闸");
//            }else if(value.equals("2")){
//                sysZhanghu.setTzglname("合闸");
//            }else{
//                sysZhanghu.setTzglname("Not selected");
//            }
//        }
//
//        if(sysZhanghu.getLqyj() != null){//功能type
//            String value = sysZhanghu.getLqyj();
//            if(value.equals("1")){
//                sysZhanghu.setLqyjname("重度漏气");
//            }else if(value.equals("2")){
//                sysZhanghu.setLqyjname("漏气");
//            }else if(value.equals("3")){
//                sysZhanghu.setLqyjname("轻度漏气");
//            }else if(value.equals("4")){
//                sysZhanghu.setLqyjname("normal");
//            }else{
//                sysZhanghu.setLqyjname("Not selected");
//            }
//        }
//        if(sysZhanghu.getSfddsj() != null){//商品类别type
//            String value = sysZhanghu.getSfddsj();
//            if(value.equals("1")){
//                sysZhanghu.setSfddsjname("是");
//            }else if(value.equals("2")){
//                sysZhanghu.setSfddsjname("否");
//            }else{
//                sysZhanghu.setSfddsjname("Not selected");
//            }
//        }
//        return sysZhanghu;
//    }
}
