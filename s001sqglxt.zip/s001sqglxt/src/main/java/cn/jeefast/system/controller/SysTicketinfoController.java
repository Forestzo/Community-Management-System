package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysTicketinfo;
import cn.jeefast.system.entity.SysTicket;
import cn.jeefast.system.service.SysTicketinfoService;
import cn.jeefast.system.service.SysTicketService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * Voting optionmanagement 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysTicketinfo")
public class SysTicketinfoController extends BaseController {
    @Autowired
    private SysTicketinfoService sysTicketinfoService;

    /**
     * Maintenance management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:ticketinfo:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysTicketinfo> pageUtil = new Page<SysTicketinfo>(query.getPage(), query.getLimit());
        Page<SysTicketinfo> page = sysTicketinfoService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Maintenance management信息
     */
    @RequestMapping("/info/{ticketinfoId}")
    @RequiresPermissions("sys:ticketinfo:info")
    public R info(@PathVariable("ticketinfoId") String ticketinfoId) {
        SysTicketinfo ticketinfo = sysTicketinfoService.selectById(ticketinfoId);
        return R.ok().put("ticketinfo", ticketinfo);
    }

    /**
     * 保存Maintenance management
     */
    @Log("保存Maintenance management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:ticketinfo:save")
    public R save(@RequestBody SysTicketinfo ticketinfo) {
        ValidatorUtils.validateEntity(ticketinfo);
        ticketinfo.setCreatetime(new Date());
        ticketinfo.setCreateuser(getUser().getUsername());
        ticketinfo.setUpdateime(new Date());
        ticketinfo.setUpdateuser(getUser().getUsername());
        sysTicketinfoService.insert(ticketinfo);
        return R.ok();
    }

    /**
     * updateMaintenance management
     */
    @Log("updateMaintenance management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:ticketinfo:update")
    public R update(@RequestBody SysTicketinfo ticketinfo) {
        ValidatorUtils.validateEntity(ticketinfo);
        ticketinfo.setUpdateime(new Date());
        ticketinfo.setUpdateuser(getUser().getUsername());
        sysTicketinfoService.updateById(ticketinfo);
        return R.ok();
    }

    /**
     * deleteMaintenance management
     */
    @Log("deleteMaintenance management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:ticketinfo:delete")
    public R delete(@RequestBody String[] ticketinfoIds) {
        sysTicketinfoService.deleteBatch(ticketinfoIds);
        return R.ok();
    }
}
