package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysPropertyDao;
import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.dao.SysAssetsDao;
import cn.jeefast.system.entity.SysProperty;
import cn.jeefast.system.service.SysAssetsService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * asset management service实现类
 * </p>
 *
 */
@Service
public class SysAssetsServiceImpl extends ServiceImpl<SysAssetsDao, SysAssets> implements SysAssetsService {

    @Autowired
    private SysAssetsDao sysAssetsDao;

    @Override
    public Page<SysAssets> queryPageList(Page<SysAssets> page, Map<String, Object> map) {
        page.setRecords(sysAssetsDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysAssetsDao.deleteBatch(ids);
    }
}
