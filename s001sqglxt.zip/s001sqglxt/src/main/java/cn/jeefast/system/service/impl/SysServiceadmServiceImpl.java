package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysMaintainDao;
import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.entity.SysServiceadm;
import cn.jeefast.system.dao.SysServiceadmDao;
import cn.jeefast.system.service.SysServiceadmService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * servicemanagement service实现类
 * </p>
 *
 */
@Service
public class SysServiceadmServiceImpl extends ServiceImpl<SysServiceadmDao, SysServiceadm> implements SysServiceadmService {
    @Autowired
    private SysServiceadmDao sysServiceadmDao;

    @Override
    public Page<SysServiceadm> queryPageList(Page<SysServiceadm> page, Map<String, Object> map) {
        page.setRecords(sysServiceadmDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysServiceadmDao.deleteBatch(ids);
    }
}
