package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysAssetsDao;
import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.entity.SysCarposition;
import cn.jeefast.system.dao.SysCarpositionDao;
import cn.jeefast.system.service.SysCarpositionService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Parking space management service实现类
 * </p>
 *
 */
@Service
public class SysCarpositionServiceImpl extends ServiceImpl<SysCarpositionDao, SysCarposition> implements SysCarpositionService {
    @Autowired
    private SysCarpositionDao sysCarpositionDao;

    @Override
    public Page<SysCarposition> queryPageList(Page<SysCarposition> page, Map<String, Object> map) {
        page.setRecords(sysCarpositionDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysCarpositionDao.deleteBatch(ids);
    }
}
