package cn.jeefast.system.dao;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import cn.jeefast.system.entity.SysRoleDept;

/**
 * <p>
  * role与部门对应关系 Mapper 接口
 * </p>
 *
 */
public interface SysRoleDeptDao extends BaseMapper<SysRoleDept> {

	/**
	 * 根据roleID，obtain 部门ID列表
	 */
	List<Long> queryDeptIdList(Long roleId);
	
	void save(Map<String, Object> map);
	
	void deleteByRoleId(Object roleId);
}