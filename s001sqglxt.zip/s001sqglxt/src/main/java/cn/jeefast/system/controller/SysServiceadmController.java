package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysServiceadm;
import cn.jeefast.system.service.SysServiceadmService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * servicemanagement 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysServiceadm")
public class SysServiceadmController extends BaseController {
    @Autowired
    private SysServiceadmService sysServiceadmService;

    /**
     * servicemanagement
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:serviceadm:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysServiceadm> pageUtil = new Page<SysServiceadm>(query.getPage(), query.getLimit());
        Page<SysServiceadm> page = sysServiceadmService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * servicemanagement信息
     */
    @RequestMapping("/info/{serviceadmId}")
    @RequiresPermissions("sys:serviceadm:info")
    public R info(@PathVariable("serviceadmId") String serviceadmId) {
        SysServiceadm serviceadm = sysServiceadmService.selectById(serviceadmId);
        return R.ok().put("serviceadm", serviceadm);
    }

    /**
     * 保存servicemanagement
     */
    @Log("保存servicemanagement")
    @RequestMapping("/save")
    @RequiresPermissions("sys:serviceadm:save")
    public R save(@RequestBody SysServiceadm serviceadm) {
        ValidatorUtils.validateEntity(serviceadm);
        serviceadm.setCreatetime(new Date());
        serviceadm.setCreateuser(getUser().getUsername());
        serviceadm.setUpdateime(new Date());
        serviceadm.setUpdateuser(getUser().getUsername());
        sysServiceadmService.insert(serviceadm);
        return R.ok();
    }

    /**
     * updateservicemanagement
     */
    @Log("updateservicemanagement")
    @RequestMapping("/update")
    @RequiresPermissions("sys:serviceadm:update")
    public R update(@RequestBody SysServiceadm serviceadm) {
        ValidatorUtils.validateEntity(serviceadm);
        serviceadm.setUpdateime(new Date());
        serviceadm.setUpdateuser(getUser().getUsername());
        sysServiceadmService.updateById(serviceadm);
        return R.ok();
    }

    /**
     * deleteservicemanagement
     */
    @Log("deleteservicemanagement")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:serviceadm:delete")
    public R delete(@RequestBody String[] serviceadmIds) {
        sysServiceadmService.deleteBatch(serviceadmIds);
        return R.ok();
    }
}
