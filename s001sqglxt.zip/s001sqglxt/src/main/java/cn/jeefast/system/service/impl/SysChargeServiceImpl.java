package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysChargeinfoDao;
import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.dao.SysChargeDao;
import cn.jeefast.system.entity.SysChargeinfo;
import cn.jeefast.system.service.SysChargeService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Charging management service实现类
 * </p>
 *
 */
@Service
public class SysChargeServiceImpl extends ServiceImpl<SysChargeDao, SysCharge> implements SysChargeService {
    @Autowired
    private SysChargeDao sysChargeDao;

    @Override
    public Page<SysCharge> queryPageList(Page<SysCharge> page, Map<String, Object> map) {
        page.setRecords(sysChargeDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysChargeDao.deleteBatch(ids);
    }
}
