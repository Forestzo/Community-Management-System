package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysTicket;
import cn.jeefast.system.service.SysTicketService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * Voting management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysTicket")
public class SysTicketController extends BaseController {

    @Autowired
    private SysTicketService sysTicketService;

    /**
     * Voting management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:ticket:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysTicket> pageUtil = new Page<SysTicket>(query.getPage(), query.getLimit());
        Page<SysTicket> page = sysTicketService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Voting management信息
     */
    @RequestMapping("/info/{ticketId}")
    @RequiresPermissions("sys:ticket:info")
    public R info(@PathVariable("ticketId") String ticketId) {
        SysTicket ticket = sysTicketService.selectById(ticketId);
        return R.ok().put("ticket", ticket);
    }

    /**
     * 保存Voting management
     */
    @Log("保存Voting management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:ticket:save")
    public R save(@RequestBody SysTicket ticket) {
        ValidatorUtils.validateEntity(ticket);
        ticket.setCreatetime(new Date());
        ticket.setCreateuser(getUser().getUsername());
        ticket.setUpdateime(new Date());
        ticket.setUpdateuser(getUser().getUsername());
        sysTicketService.insert(ticket);
        return R.ok();
    }

    /**
     * updateVoting management
     */
    @Log("updateVoting management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:ticket:update")
    public R update(@RequestBody SysTicket ticket) {
        ValidatorUtils.validateEntity(ticket);
        ticket.setUpdateime(new Date());
        ticket.setUpdateuser(getUser().getUsername());
        sysTicketService.updateById(ticket);
        return R.ok();
    }

    /**
     * deleteVoting management
     */
    @Log("deleteVoting management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:ticket:delete")
    public R delete(@RequestBody String[] ticketIds) {
        sysTicketService.deleteBatch(ticketIds);
        return R.ok();
    }
}
