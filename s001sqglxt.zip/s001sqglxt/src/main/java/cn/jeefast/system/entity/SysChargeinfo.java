package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * Charging record management
 * </p>
 *
 */
@TableName("sys_chargeinfo")
public class SysChargeinfo extends Model<SysChargeinfo> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * 社区id 
     */
	private String deptid;
    /**
     * Recharge personnel
     */
	private String username;
    /**
     * Recharge amount
     */
	private Double cost;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;
    /**
     * 重置managementid
     */
	private String chargeid;

	@TableField(exist=false)
	private String deptName;

	@TableField(exist=false)
	private String realname;

	private String type;

	@TableField(exist=false)
	private String typeName;

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getRealname() {
		return realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public String getChargeid() {
		return chargeid;
	}

	public void setChargeid(String chargeid) {
		this.chargeid = chargeid;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "SysChargeinfo{" +
				"id='" + id + '\'' +
				", deptid='" + deptid + '\'' +
				", username='" + username + '\'' +
				", cost=" + cost +
				", createtime=" + createtime +
				", updateime=" + updateime +
				", createuser='" + createuser + '\'' +
				", updateuser='" + updateuser + '\'' +
				", chargeid='" + chargeid + '\'' +
				", deptName='" + deptName + '\'' +
				", realname='" + realname + '\'' +
				", type='" + type + '\'' +
				", typeName='" + typeName + '\'' +
				'}';
	}
}
