package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * Voting management
 * </p>
 *
 */
@TableName("sys_ticket")
public class SysTicket extends Model<SysTicket> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * title
     */
	private String name;
    /**
     * Details
     */
	private String content;
    /**
     * Community
     */
	private String deptid;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;

	@TableField(exist=false)
	private String deptName;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "SysTicket{" +
				"id='" + id + '\'' +
				", name='" + name + '\'' +
				", content='" + content + '\'' +
				", deptid='" + deptid + '\'' +
				", createtime=" + createtime +
				", updateime=" + updateime +
				", createuser='" + createuser + '\'' +
				", updateuser='" + updateuser + '\'' +
				", deptName='" + deptName + '\'' +
				'}';
	}
}
