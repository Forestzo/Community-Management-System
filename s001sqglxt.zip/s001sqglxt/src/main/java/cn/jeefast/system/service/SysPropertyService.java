package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysPjinfo;
import cn.jeefast.system.entity.SysProperty;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Property management service类
 * </p>
 *
 */
public interface SysPropertyService extends IService<SysProperty> {
    Page<SysProperty> queryPageList(Page<SysProperty> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
