package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.service.SysMaintainService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * Maintenance management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysMaintain")
public class SysMaintainController extends BaseController {

    @Autowired
    private SysMaintainService sysMaintainService;

    /**
     * Maintenance management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:maintain:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysMaintain> pageUtil = new Page<SysMaintain>(query.getPage(), query.getLimit());
        Page<SysMaintain> page = sysMaintainService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Maintenance management信息
     */
    @RequestMapping("/info/{maintainId}")
    @RequiresPermissions("sys:maintain:info")
    public R info(@PathVariable("maintainId") String maintainId) {
        SysMaintain maintain = sysMaintainService.selectById(maintainId);
        return R.ok().put("maintain", maintain);
    }

    /**
     * 保存Maintenance management
     */
    @Log("保存Maintenance management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:maintain:save")
    public R save(@RequestBody SysMaintain maintain) {
        ValidatorUtils.validateEntity(maintain);
        maintain.setCreatetime(new Date());
        maintain.setCreateuser(getUser().getUsername());
        maintain.setUpdateime(new Date());
        maintain.setUpdateuser(getUser().getUsername());
        sysMaintainService.insert(maintain);
        return R.ok();
    }

    /**
     * updateMaintenance management
     */
    @Log("updateMaintenance management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:maintain:update")
    public R update(@RequestBody SysMaintain maintain) {
        ValidatorUtils.validateEntity(maintain);
        maintain.setUpdateime(new Date());
        maintain.setUpdateuser(getUser().getUsername());
        sysMaintainService.updateById(maintain);
        return R.ok();
    }

    /**
     * deleteMaintenance management
     */
    @Log("deleteMaintenance management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:maintain:delete")
    public R delete(@RequestBody String[] maintainIds) {
        sysMaintainService.deleteBatch(maintainIds);
        return R.ok();
    }

}
