package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysMaintainDao;
import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.entity.SysTicketinfo;
import cn.jeefast.system.dao.SysTicketinfoDao;
import cn.jeefast.system.service.SysTicketinfoService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Voting optionmanagement service实现类
 * </p>
 *
 */
@Service
public class SysTicketinfoServiceImpl extends ServiceImpl<SysTicketinfoDao, SysTicketinfo> implements SysTicketinfoService {
    @Autowired
    private SysTicketinfoDao sysTicketinfoDao;

    @Override
    public Page<SysTicketinfo> queryPageList(Page<SysTicketinfo> page, Map<String, Object> map) {
        page.setRecords(sysTicketinfoDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysTicketinfoDao.deleteBatch(ids);
    }
}
