package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.entity.SysPublicservice;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * 公共设施信息表 Mapper 接口
 * </p>
 *
 */
public interface SysPublicserviceDao extends BaseMapper<SysPublicservice> {
    List<SysPublicservice> queryPageList(Page<SysPublicservice> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}