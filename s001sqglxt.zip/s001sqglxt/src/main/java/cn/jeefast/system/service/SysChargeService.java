package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.entity.SysChargeinfo;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Charging management service类
 * </p>
 *
 */
public interface SysChargeService extends IService<SysCharge> {
    Page<SysCharge> queryPageList(Page<SysCharge> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
