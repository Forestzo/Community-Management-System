package cn.jeefast.system.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.system.entity.SysUser;

/**
 * <p>
 * 系统user service类
 * </p>
 */
public interface SysUserService extends IService<SysUser> {
	
	Page<SysUser> queryPageList(Page<SysUser> pageUtil, Map<String, Object> map);
	
	/**
	 * queryuser列表
	 */
	List<SysUser> queryList(Map<String, Object> map);
	
	/**
	 * queryuser的所有权限
	 * @param userId  userID
	 */
	List<String> queryAllPerms(Long userId);
	
	/**
	 * queryuser的所有menuID
	 */
	List<Long> queryAllMenuId(Long userId);

	/**
	 * 根据user名，query系统user
	 */
	SysUser queryByUserName(String username);
	
	/**
	 * deleteuser
	 */
	void deleteBatch(Long[] userIds);

	void save(SysUser user);

	void update(SysUser user);


}
