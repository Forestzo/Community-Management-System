package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.entity.SysTicketinfo;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Voting optionmanagement service类
 * </p>
 *
 */
public interface SysTicketinfoService extends IService<SysTicketinfo> {
    Page<SysTicketinfo> queryPageList(Page<SysTicketinfo> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
