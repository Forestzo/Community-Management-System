package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysChargeinfo;
import cn.jeefast.system.service.SysChargeinfoService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * Charging record management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysChargeinfo")
public class SysChargeinfoController extends BaseController {

    @Autowired
    private SysChargeinfoService sysChargeinfoService;

    /**
     * Charging record management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:chargeinfo:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysChargeinfo> pageUtil = new Page<SysChargeinfo>(query.getPage(), query.getLimit());
        Page<SysChargeinfo> page = sysChargeinfoService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Charging record management信息
     */
    @RequestMapping("/info/{chargeinfoId}")
    @RequiresPermissions("sys:chargeinfo:info")
    public R info(@PathVariable("chargeinfoId") String chargeinfoId) {
        SysChargeinfo chargeinfo = sysChargeinfoService.selectById(chargeinfoId);
        return R.ok().put("chargeinfo", chargeinfo);
    }

    /**
     * 保存Charging record management
     */
    @Log("保存Charging record management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:chargeinfo:save")
    public R save(@RequestBody SysChargeinfo chargeinfo) {
        ValidatorUtils.validateEntity(chargeinfo);
        chargeinfo.setCreatetime(new Date());
        chargeinfo.setCreateuser(getUser().getUsername());
        chargeinfo.setUpdateime(new Date());
        chargeinfo.setUpdateuser(getUser().getUsername());
        sysChargeinfoService.insert(chargeinfo);
        return R.ok();
    }

    /**
     * updateCharging record management
     */
    @Log("updateCharging record management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:chargeinfo:update")
    public R update(@RequestBody SysChargeinfo chargeinfo) {
        ValidatorUtils.validateEntity(chargeinfo);
        chargeinfo.setUpdateime(new Date());
        chargeinfo.setUpdateuser(getUser().getUsername());
        sysChargeinfoService.updateById(chargeinfo);
        return R.ok();
    }

    /**
     * deleteCharging record management
     */
    @Log("deleteCharging record management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:chargeinfo:delete")
    public R delete(@RequestBody String[] chargeinfoIds) {
        sysChargeinfoService.deleteBatch(chargeinfoIds);
        return R.ok();
    }
}
