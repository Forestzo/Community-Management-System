package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysTicket;
import cn.jeefast.system.entity.SysTicketinfo;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Voting management service类
 * </p>
 *
 */
public interface SysTicketService extends IService<SysTicket> {
    Page<SysTicket> queryPageList(Page<SysTicket> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
