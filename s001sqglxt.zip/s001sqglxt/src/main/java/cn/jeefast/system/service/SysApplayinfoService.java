package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.entity.SysMaintain;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * 公共申请service service类
 * </p>
 *
 */
public interface SysApplayinfoService extends IService<SysApplayinfo> {
    Page<SysApplayinfo> queryPageList(Page<SysApplayinfo> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
