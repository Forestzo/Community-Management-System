package cn.jeefast.system.service;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.system.entity.SysMenu;

/**
 * <p>
 * menumanagement service类
 * </p>
 *
 */
public interface SysMenuService extends IService<SysMenu> {
	/**
	 * 根据父menu，query子menu
	 * @param parentId 父menuID
	 * @param menuIdList  usermenuID
	 */
	List<SysMenu> queryListParentId(Long parentId, List<Long> menuIdList);

	/**
	 * 根据父menu，query子menu
	 * @param parentId 父menuID
	 */
	List<SysMenu> queryListParentId(Long parentId);
	
	/**
	 * obtain No包含Button的menu列表
	 */
	List<SysMenu> queryNotButtonList();
	
	/**
	 * obtain usermenu列表
	 */
	List<SysMenu> getUserMenuList(Long userId);
	
	/**
	 * querymenu列表
	 */
	List<SysMenu> queryList(Map<String, Object> map);
	
	/**
	 * delete
	 */
	void deleteBatch(Long[] menuIds);
	
	/**
	 * queryuser的权限列表
	 */
	List<SysMenu> queryUserList(Long userId);
}
