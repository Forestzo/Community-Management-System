package cn.jeefast.system.service;

import java.util.Set;

import cn.jeefast.system.entity.SysUser;
import cn.jeefast.system.entity.SysUserToken;

/**
 * shiro相关接口
 */
public interface ShiroService {
    /**
     * obtain user权限列表
     */
    Set<String> getUserPermissions(long userId);

    SysUserToken queryByToken(String token);

    /**
     * 根据userID，queryuser
     * @param userId
     */
    SysUser queryUser(Long userId);
}
