package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.entity.SysCarposition;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * Parking space management service类
 * </p>
 *
 */
public interface SysCarpositionService extends IService<SysCarposition> {
    Page<SysCarposition> queryPageList(Page<SysCarposition> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
