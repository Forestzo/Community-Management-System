package cn.jeefast.system.entity;

import java.io.Serializable;
import java.util.List;

import com.baomidou.mybatisplus.enums.IdType;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;

/**
 * <p>
 * Department management
 * </p>
 *
 */
@TableName("sys_dept")
public class SysDept extends Model<SysDept> {

	private static final long serialVersionUID = 1L;

	@TableId(value="dept_id", type= IdType.AUTO)
	private Long deptId;
	/**
	 * Superior departmentID，一级部门为0
	 */
	@TableField("parent_id")
	private Long parentId;
	/**
	 * Department name
	 */
	private String name;
	/**
	 * 排序
	 */
	@TableField("order_num")
	private Integer orderNum;
	/**
	 * 是否delete  -1：已delete  0：normal
	 */
	@TableField("del_flag")
	private Integer delFlag;

	/**
	 * superiorDepartment name
	 */
	@TableField(exist=false)
	private String parentName;
	/**
	 * ztree属性
	 */
	@TableField(exist=false)
	private Boolean open;

	@TableField(exist=false)
	private List<?> list;

	/**
	 * 统计部门人数
	 */
	@TableField(exist=false)
	private Integer rs;

	private String upstr;

	private String downstr;

	public Integer getRs() {
		return rs;
	}

	public void setRs(Integer rs) {
		this.rs = rs;
	}

	public String getUpstr() {
		return upstr;
	}

	public void setUpstr(String upstr) {
		this.upstr = upstr;
	}

	public String getDownstr() {
		return downstr;
	}

	public void setDownstr(String downstr) {
		this.downstr = downstr;
	}

	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	public Integer getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public Boolean getOpen() {
		return open;
	}

	public void setOpen(Boolean open) {
		this.open = open;
	}

	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

	@Override
	protected Serializable pkVal() {
		return this.deptId;
	}

	@Override
	public String toString() {
		return "SysDept{" +
				"deptId=" + deptId +
				", parentId=" + parentId +
				", name='" + name + '\'' +
				", orderNum=" + orderNum +
				", delFlag=" + delFlag +
				", parentName='" + parentName + '\'' +
				", open=" + open +
				", list=" + list +
				", rs=" + rs +
				", upstr='" + upstr + '\'' +
				", downstr='" + downstr + '\'' +
				'}';
	}
}
