package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysApplayinfoDao;
import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.entity.SysPublicservice;
import cn.jeefast.system.dao.SysPublicserviceDao;
import cn.jeefast.system.service.SysPublicserviceService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * 公共设施信息表 service实现类
 * </p>
 *
 */
@Service
public class SysPublicserviceServiceImpl extends ServiceImpl<SysPublicserviceDao, SysPublicservice> implements SysPublicserviceService {
    @Autowired
    private SysPublicserviceDao sysPublicserviceDao;

    @Override
    public Page<SysPublicservice> queryPageList(Page<SysPublicservice> page, Map<String, Object> map) {
        page.setRecords(sysPublicserviceDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysPublicserviceDao.deleteBatch(ids);
    }
}
