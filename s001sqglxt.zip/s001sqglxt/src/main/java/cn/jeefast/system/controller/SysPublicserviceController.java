package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysPublicservice;
import cn.jeefast.system.service.SysPublicserviceService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * 公共设施信息表 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysPublicservice")
public class SysPublicserviceController extends BaseController {

    @Autowired
    private SysPublicserviceService sysPublicserviceService;

    /**
     * 公共设施信息表
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:publicservice:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysPublicservice> pageUtil = new Page<SysPublicservice>(query.getPage(), query.getLimit());
        Page<SysPublicservice> page = sysPublicserviceService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * 公共设施信息表信息
     */
    @RequestMapping("/info/{publicserviceId}")
    @RequiresPermissions("sys:publicservice:info")
    public R info(@PathVariable("publicserviceId") String publicserviceId) {
        SysPublicservice publicservice = sysPublicserviceService.selectById(publicserviceId);
        return R.ok().put("publicservice", publicservice);
    }

    /**
     * 保存公共设施信息表
     */
    @Log("保存公共设施信息表")
    @RequestMapping("/save")
    @RequiresPermissions("sys:publicservice:save")
    public R save(@RequestBody SysPublicservice publicservice) {
        ValidatorUtils.validateEntity(publicservice);
        publicservice.setCreatetime(new Date());
        publicservice.setCreateuser(getUser().getUsername());
        publicservice.setUpdateime(new Date());
        publicservice.setUpdateuser(getUser().getUsername());
        sysPublicserviceService.insert(publicservice);
        return R.ok();
    }

    /**
     * update公共设施信息表
     */
    @Log("update公共设施信息表")
    @RequestMapping("/update")
    @RequiresPermissions("sys:publicservice:update")
    public R update(@RequestBody SysPublicservice publicservice) {
        ValidatorUtils.validateEntity(publicservice);
        publicservice.setUpdateime(new Date());
        publicservice.setUpdateuser(getUser().getUsername());
        sysPublicserviceService.updateById(publicservice);
        return R.ok();
    }

    /**
     * delete公共设施信息表
     */
    @Log("delete公共设施信息表")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:publicservice:delete")
    public R delete(@RequestBody String[] publicserviceIds) {
        sysPublicserviceService.deleteBatch(publicserviceIds);
        return R.ok();
    }
}
