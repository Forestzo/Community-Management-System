package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.service.SysApplayinfoService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * 公共申请service 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysApplayinfo")
public class SysApplayinfoController extends BaseController {

    @Autowired
    private SysApplayinfoService sysApplayinfoService;

    /**
     * 公共申请service
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:applayinfo:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysApplayinfo> pageUtil = new Page<SysApplayinfo>(query.getPage(), query.getLimit());
        Page<SysApplayinfo> page = sysApplayinfoService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * 公共申请service信息
     */
    @RequestMapping("/info/{applayinfoId}")
    @RequiresPermissions("sys:applayinfo:info")
    public R info(@PathVariable("applayinfoId") String applayinfoId) {
        SysApplayinfo applayinfo = sysApplayinfoService.selectById(applayinfoId);
        return R.ok().put("applayinfo", applayinfo);
    }

    /**
     * 保存公共申请service
     */
    @Log("保存公共申请service")
    @RequestMapping("/save")
    @RequiresPermissions("sys:applayinfo:save")
    public R save(@RequestBody SysApplayinfo applayinfo) {
        ValidatorUtils.validateEntity(applayinfo);
        applayinfo.setCreatetime(new Date());
        applayinfo.setCreateuser(getUser().getUsername());
        applayinfo.setUpdateime(new Date());
        applayinfo.setUpdateuser(getUser().getUsername());
        sysApplayinfoService.insert(applayinfo);
        return R.ok();
    }

    /**
     * update公共申请service
     */
    @Log("update公共申请service")
    @RequestMapping("/update")
    @RequiresPermissions("sys:applayinfo:update")
    public R update(@RequestBody SysApplayinfo applayinfo) {
        ValidatorUtils.validateEntity(applayinfo);
        applayinfo.setUpdateime(new Date());
        applayinfo.setUpdateuser(getUser().getUsername());
        sysApplayinfoService.updateById(applayinfo);
        return R.ok();
    }

    /**
     * delete公共申请service
     */
    @Log("delete公共申请service")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:applayinfo:delete")
    public R delete(@RequestBody String[] applayinfoIds) {
        sysApplayinfoService.deleteBatch(applayinfoIds);
        return R.ok();
    }
}
