package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.entity.SysPublicservice;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * 公共设施信息表 service类
 * </p>
 *
 */
public interface SysPublicserviceService extends IService<SysPublicservice> {
    Page<SysPublicservice> queryPageList(Page<SysPublicservice> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
