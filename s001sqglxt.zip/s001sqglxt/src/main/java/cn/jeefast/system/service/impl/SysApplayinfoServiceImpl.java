package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysMaintainDao;
import cn.jeefast.system.entity.SysApplayinfo;
import cn.jeefast.system.dao.SysApplayinfoDao;
import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.service.SysApplayinfoService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * 公共申请service service实现类
 * </p>
 *
 */
@Service
public class SysApplayinfoServiceImpl extends ServiceImpl<SysApplayinfoDao, SysApplayinfo> implements SysApplayinfoService {
    @Autowired
    private SysApplayinfoDao sysApplayinfoDao;

    @Override
    public Page<SysApplayinfo> queryPageList(Page<SysApplayinfo> page, Map<String, Object> map) {
        page.setRecords(sysApplayinfoDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysApplayinfoDao.deleteBatch(ids);
    }
}
