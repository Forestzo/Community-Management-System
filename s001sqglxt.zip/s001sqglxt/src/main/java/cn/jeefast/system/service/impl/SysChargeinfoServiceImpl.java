package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysCarpositionDao;
import cn.jeefast.system.entity.SysCarposition;
import cn.jeefast.system.entity.SysChargeinfo;
import cn.jeefast.system.dao.SysChargeinfoDao;
import cn.jeefast.system.service.SysChargeinfoService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Charging record management service实现类
 * </p>
 *
 */
@Service
public class SysChargeinfoServiceImpl extends ServiceImpl<SysChargeinfoDao, SysChargeinfo> implements SysChargeinfoService {
    @Autowired
    private SysChargeinfoDao sysChargeinfoDao;

    @Override
    public Page<SysChargeinfo> queryPageList(Page<SysChargeinfo> page, Map<String, Object> map) {
        page.setRecords(sysChargeinfoDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysChargeinfoDao.deleteBatch(ids);
    }
}
