package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysChargeDao;
import cn.jeefast.system.entity.SysCharge;
import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.dao.SysMaintainDao;
import cn.jeefast.system.service.SysMaintainService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Maintenance management service实现类
 * </p>
 *
 */
@Service
public class SysMaintainServiceImpl extends ServiceImpl<SysMaintainDao, SysMaintain> implements SysMaintainService {
    @Autowired
    private SysMaintainDao sysMaintainDao;

    @Override
    public Page<SysMaintain> queryPageList(Page<SysMaintain> page, Map<String, Object> map) {
        page.setRecords(sysMaintainDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysMaintainDao.deleteBatch(ids);
    }
}
