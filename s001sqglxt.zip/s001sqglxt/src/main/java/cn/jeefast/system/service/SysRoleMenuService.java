package cn.jeefast.system.service;

import java.util.List;

import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.system.entity.SysRoleMenu;

/**
 * <p>
 * role与menu对应关系 service类
 * </p>
 *
 */
public interface SysRoleMenuService extends IService<SysRoleMenu> {
	void saveOrUpdate(Long roleId, List<Long> menuIdList);
	
	/**
	 * 根据roleID，obtain menuID列表
	 */
	List<Long> queryMenuIdList(Long roleId);
}
