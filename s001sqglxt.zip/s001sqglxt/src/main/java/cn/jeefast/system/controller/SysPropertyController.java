package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.*;
import cn.jeefast.system.service.SysPropertyService;
import cn.jeefast.system.service.SysUserTokenService;
import cn.jeefast.system.service.TMaterialFileService;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Property management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysProperty")
public class SysPropertyController extends BaseController {
    @Autowired
    private SysPropertyService sysPropertyService;

    /**
     * Property management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:property:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysProperty> pageUtil = new Page<SysProperty>(query.getPage(), query.getLimit());
        Page<SysProperty> page = sysPropertyService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * Property management信息
     */
    @RequestMapping("/info/{propertyId}")
    @RequiresPermissions("sys:property:info")
    public R info(@PathVariable("propertyId") String propertyId) {
        SysProperty property = sysPropertyService.selectById(propertyId);
        return R.ok().put("property", property);
    }

    /**
     * 保存Property management
     */
    @Log("保存Property management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:property:save")
    public R save(@RequestBody SysProperty property) {
        ValidatorUtils.validateEntity(property);
        property.setCreatetime(new Date());
        property.setCreateuser(getUser().getUsername());
        property.setUpdateime(new Date());
        property.setUpdateuser(getUser().getUsername());
        sysPropertyService.insert(property);
        return R.ok();
    }

    /**
     * updateProperty management
     */
    @Log("updateProperty management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:property:update")
    public R update(@RequestBody SysProperty property) {
        ValidatorUtils.validateEntity(property);
        property.setUpdateime(new Date());
        property.setUpdateuser(getUser().getUsername());
        sysPropertyService.updateById(property);
        return R.ok();
    }

    /**
     * deleteProperty management
     */
    @Log("deleteProperty management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:property:delete")
    public R delete(@RequestBody String[] propertyIds) {
        sysPropertyService.deleteBatch(propertyIds);
        return R.ok();
    }
}
