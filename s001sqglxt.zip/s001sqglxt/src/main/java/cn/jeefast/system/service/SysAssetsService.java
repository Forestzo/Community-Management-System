package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.entity.SysProperty;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * asset management service类
 * </p>
 *
 */
public interface SysAssetsService extends IService<SysAssets> {
    Page<SysAssets> queryPageList(Page<SysAssets> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
