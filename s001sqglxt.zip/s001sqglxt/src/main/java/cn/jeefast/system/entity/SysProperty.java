package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * Property management
 * </p>
 *
 */
@TableName("sys_property")
public class SysProperty extends Model<SysProperty> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * Community
     */
	private String deptid;
    /**
     * Property name
     */
	private String name;
    /**
     * introduce
     */
	private String content;
    /**
     * Property Manager
     */
	private String peple;
    /**
     * Contact information of person in charge
     */
	private String mobile;
    /**
     * Property fee1²
     */
	private Double cost;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPeple() {
		return peple;
	}

	public void setPeple(String peple) {
		this.peple = peple;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "SysProperty{" +
			", id=" + id +
			", deptid=" + deptid +
			", name=" + name +
			", content=" + content +
			", peple=" + peple +
			", mobile=" + mobile +
			", cost=" + cost +
			", createtime=" + createtime +
			", updateime=" + updateime +
			", createuser=" + createuser +
			", updateuser=" + updateuser +
			"}";
	}
}
