package cn.jeefast.system.controller;


import cn.jeefast.common.annotation.Log;
import cn.jeefast.common.utils.Query;
import cn.jeefast.common.utils.R;
import cn.jeefast.common.validator.ValidatorUtils;
import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.service.SysAssetsService;
import com.baomidou.mybatisplus.plugins.Page;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import cn.jeefast.common.base.BaseController;

import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;

/**
 * <p>
 * asset management 前端控制器
 * </p>
 *
 */
@RestController
@RequestMapping("/sysAssets")
public class SysAssetsController extends BaseController {

    @Autowired
    private SysAssetsService sysAssetsService;

    /**
     * asset management
     */
    @RequestMapping("/list")
    @RequiresPermissions("sys:assets:list")
    public R list(@RequestParam Map<String, Object> params) throws UnknownHostException {
        //query列表数据
        Query query = new Query(params);
        Page<SysAssets> pageUtil = new Page<SysAssets>(query.getPage(), query.getLimit());
        Page<SysAssets> page = sysAssetsService.queryPageList(pageUtil, query);
        return R.ok().put("page", page);
    }

    /**
     * asset management信息
     */
    @RequestMapping("/info/{assetsId}")
    @RequiresPermissions("sys:assets:info")
    public R info(@PathVariable("assetsId") String assetsId) {
        SysAssets assets = sysAssetsService.selectById(assetsId);
        return R.ok().put("assets", assets);
    }

    /**
     * 保存asset management
     */
    @Log("保存asset management")
    @RequestMapping("/save")
    @RequiresPermissions("sys:assets:save")
    public R save(@RequestBody SysAssets assets) {
        ValidatorUtils.validateEntity(assets);
        assets.setCreatetime(new Date());
        assets.setCreateuser(getUser().getUsername());
        assets.setUpdateime(new Date());
        assets.setUpdateuser(getUser().getUsername());
        sysAssetsService.insert(assets);
        return R.ok();
    }

    /**
     * updateasset management
     */
    @Log("updateasset management")
    @RequestMapping("/update")
    @RequiresPermissions("sys:assets:update")
    public R update(@RequestBody SysAssets assets) {
        ValidatorUtils.validateEntity(assets);
        assets.setUpdateime(new Date());
        assets.setUpdateuser(getUser().getUsername());
        sysAssetsService.updateById(assets);
        return R.ok();
    }

    /**
     * deleteasset management
     */
    @Log("deleteasset management")
    @RequestMapping("/delete")
    @RequiresPermissions("sys:assets:delete")
    public R delete(@RequestBody String[] assetsIds) {
        sysAssetsService.deleteBatch(assetsIds);
        return R.ok();
    }
}
