package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysCarposition;
import cn.jeefast.system.entity.SysCharge;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * Charging management Mapper 接口
 * </p>
 *
 */
public interface SysChargeDao extends BaseMapper<SysCharge> {
    List<SysCharge> queryPageList(Page<SysCharge> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}