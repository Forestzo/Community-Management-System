package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * 公共申请service
 * </p>
 *
 */
@TableName("sys_applayinfo")
public class SysApplayinfo extends Model<SysApplayinfo> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * apply title
     */
	private String name;
    /**
     * 申请 content
     */
	private String content;
    /**
     * Application time
     */
	private Date sqsj;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;
    /**
     * 公共serviceid
     */
	private String publicserviceid;

	/**
	 * 社区id
	 */
	private String deptid;

	/**
	 * Department name
	 */
	@TableField(exist=false)
	private String deptName;

	@TableField(exist=false)
	private String publicservicename;

	public String getPublicservicename() {
		return publicservicename;
	}

	public void setPublicservicename(String publicservicename) {
		this.publicservicename = publicservicename;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getSqsj() {
		return sqsj;
	}

	public void setSqsj(Date sqsj) {
		this.sqsj = sqsj;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public String getPublicserviceid() {
		return publicserviceid;
	}

	public void setPublicserviceid(String publicserviceid) {
		this.publicserviceid = publicserviceid;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "SysApplayinfo{" +
				"id='" + id + '\'' +
				", name='" + name + '\'' +
				", content='" + content + '\'' +
				", sqsj=" + sqsj +
				", createtime=" + createtime +
				", updateime=" + updateime +
				", createuser='" + createuser + '\'' +
				", updateuser='" + updateuser + '\'' +
				", publicserviceid='" + publicserviceid + '\'' +
				", deptid='" + deptid + '\'' +
				", deptName='" + deptName + '\'' +
				", publicservicename='" + publicservicename + '\'' +
				'}';
	}
}
