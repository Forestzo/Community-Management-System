package cn.jeefast.system.dao;

import cn.jeefast.system.entity.SysAssets;
import cn.jeefast.system.entity.SysCarposition;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * Parking space management Mapper 接口
 * </p>
 *
 */
public interface SysCarpositionDao extends BaseMapper<SysCarposition> {
    List<SysCarposition> queryPageList(Page<SysCarposition> page, Map<String, Object> map);

    int deleteBatch(Object[] id);
}