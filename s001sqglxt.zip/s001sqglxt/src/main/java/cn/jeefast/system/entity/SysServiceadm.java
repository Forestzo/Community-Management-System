package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * servicemanagement
 * </p>
 *
 */
@TableName("sys_serviceadm")
public class SysServiceadm extends Model<SysServiceadm> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * servicetitle
     */
	private String name;
    /**
     * service content
     */
	private String content;
    /**
     * Is it solved1：是2：否
     */
	private String type;
    /**
     * 解决方式
     */
	private String metcont;
	@TableField("sys_charge")
	private String sysCharge;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;
    /**
     * Community
     */
	private String deptid;

	@TableField(exist=false)
	private String deptName;

	/**
	 * servicetype1：goodsquery2：provide home delivery service
	 */
	private String fl;

    /**
     * servicetype1：goodsquery2：provide home delivery service
     */
    @TableField(exist=false)
    private String flName;

	private String username;

    public String getFlName() {
        return flName;
    }

    public void setFlName(String flName) {
        this.flName = flName;
    }

    public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFl() {
		return fl;
	}

	public void setFl(String fl) {
		this.fl = fl;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMetcont() {
		return metcont;
	}

	public void setMetcont(String metcont) {
		this.metcont = metcont;
	}

	public String getSysCharge() {
		return sysCharge;
	}

	public void setSysCharge(String sysCharge) {
		this.sysCharge = sysCharge;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

    @Override
    public String toString() {
        return "SysServiceadm{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", content='" + content + '\'' +
                ", type='" + type + '\'' +
                ", metcont='" + metcont + '\'' +
                ", sysCharge='" + sysCharge + '\'' +
                ", createtime=" + createtime +
                ", updateime=" + updateime +
                ", createuser='" + createuser + '\'' +
                ", updateuser='" + updateuser + '\'' +
                ", deptid='" + deptid + '\'' +
                ", deptName='" + deptName + '\'' +
                ", fl='" + fl + '\'' +
                ", flName='" + flName + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
