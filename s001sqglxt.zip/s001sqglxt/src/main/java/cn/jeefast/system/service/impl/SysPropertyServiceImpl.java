package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysPjinfoDao;
import cn.jeefast.system.entity.SysPjinfo;
import cn.jeefast.system.entity.SysProperty;
import cn.jeefast.system.dao.SysPropertyDao;
import cn.jeefast.system.service.SysPropertyService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Property management service实现类
 * </p>
 *
 */
@Service
public class SysPropertyServiceImpl extends ServiceImpl<SysPropertyDao, SysProperty> implements SysPropertyService {

    @Autowired
    private SysPropertyDao sysPropertyDao;

    @Override
    public Page<SysProperty> queryPageList(Page<SysProperty> page, Map<String, Object> map) {
        page.setRecords(sysPropertyDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysPropertyDao.deleteBatch(ids);
    }
}
