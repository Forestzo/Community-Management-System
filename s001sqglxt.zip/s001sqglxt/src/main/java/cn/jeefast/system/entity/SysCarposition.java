package cn.jeefast.system.entity;

import java.io.Serializable;

import java.util.Date;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;

/**
 * <p>
 * Parking space management
 * </p>
 *
 */
@TableName("sys_carposition")
public class SysCarposition extends Model<SysCarposition> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId(type = IdType.UUID)
	private String id;
    /**
     * Parking space number
     */
	private String numb;
    /**
     * type1：Private parking space2：Rental parking space 3：Public parking space 4：other
     */
	private String type;
    /**
     * Usage status1：in use2：free3：Under repair4：other
     */
	private String usagestatus;
    /**
     * Price元/天
     */
	private Double cost;
    /**
     * Parking space sizestate1：大2：中3：小
     */
	private String bigtype;
    /**
     * create time
     */
	private Date createtime;
    /**
     * 更新时间
     */
	private Date updateime;
    /**
     * 创建 personnel
     */
	private String createuser;
    /**
     * 更新 personnel
     */
	private String updateuser;
    /**
     * 社区id
     */
	private String deptid;
    /**
     * 所属user
     */
	private String username;


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNumb() {
		return numb;
	}

	public void setNumb(String numb) {
		this.numb = numb;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUsagestatus() {
		return usagestatus;
	}

	public void setUsagestatus(String usagestatus) {
		this.usagestatus = usagestatus;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public String getBigtype() {
		return bigtype;
	}

	public void setBigtype(String bigtype) {
		this.bigtype = bigtype;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Date getUpdateime() {
		return updateime;
	}

	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}

	public String getCreateuser() {
		return createuser;
	}

	public void setCreateuser(String createuser) {
		this.createuser = createuser;
	}

	public String getUpdateuser() {
		return updateuser;
	}

	public void setUpdateuser(String updateuser) {
		this.updateuser = updateuser;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "SysCarposition{" +
			", id=" + id +
			", numb=" + numb +
			", type=" + type +
			", usagestatus=" + usagestatus +
			", cost=" + cost +
			", bigtype=" + bigtype +
			", createtime=" + createtime +
			", updateime=" + updateime +
			", createuser=" + createuser +
			", updateuser=" + updateuser +
			", deptid=" + deptid +
			", username=" + username +
			"}";
	}
}
