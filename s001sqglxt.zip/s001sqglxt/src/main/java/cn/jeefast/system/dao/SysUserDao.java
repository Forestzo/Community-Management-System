package cn.jeefast.system.dao;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.Page;

import cn.jeefast.system.entity.SysUser;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
  * 系统user Mapper 接口
 * </p>
 *
 */
public interface SysUserDao extends BaseMapper<SysUser> {
	
	List<SysUser> queryPageList(Page<SysUser> page, Map<String, Object> map);

	List<SysUser> queryList(Map<String, Object> map);
	
	/**
	 * queryuser的所有权限
	 * @param userId  userID
	 */
	List<String> queryAllPerms(Long userId);
	
	/**
	 * queryuser的所有menuID
	 */
	List<Long> queryAllMenuId(Long userId);
	
	/**
	 * 根据user名，query系统user
	 */
	SysUser queryByUserName(String username);
	
	int deleteBatch(Object[] id);


}