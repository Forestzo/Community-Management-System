package cn.jeefast.system.service.impl;

import cn.jeefast.system.dao.SysTicketinfoDao;
import cn.jeefast.system.entity.SysTicket;
import cn.jeefast.system.dao.SysTicketDao;
import cn.jeefast.system.entity.SysTicketinfo;
import cn.jeefast.system.service.SysTicketService;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * <p>
 * Voting management service实现类
 * </p>
 *
 */
@Service
public class SysTicketServiceImpl extends ServiceImpl<SysTicketDao, SysTicket> implements SysTicketService {
    @Autowired
    private SysTicketDao sysTicketDao;

    @Override
    public Page<SysTicket> queryPageList(Page<SysTicket> page, Map<String, Object> map) {
        page.setRecords(sysTicketDao.queryPageList(page, map));
        return page;
    }

    @Override
    public void deleteBatch(String[] ids) {
        sysTicketDao.deleteBatch(ids);
    }
}
