package cn.jeefast.system.service;

import cn.jeefast.system.entity.SysMaintain;
import cn.jeefast.system.entity.SysServiceadm;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;

import java.util.Map;

/**
 * <p>
 * servicemanagement service类
 * </p>
 *
 */
public interface SysServiceadmService extends IService<SysServiceadm> {
    Page<SysServiceadm> queryPageList(Page<SysServiceadm> page, Map<String, Object> map);
    void deleteBatch(String[] ids);
}
