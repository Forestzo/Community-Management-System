package cn.jeefast.system.dao;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.mapper.BaseMapper;

import cn.jeefast.system.entity.SysMenu;

/**
 * <p>
  * menumanagement Mapper 接口
 * </p>
 *
 */
public interface SysMenuDao extends BaseMapper<SysMenu> {
	
	List<SysMenu> queryList(Map<String, Object> map);

	/**
	 * 根据父menu，query子menu
	 * @param parentId 父menuID
	 */
	List<SysMenu> queryListParentId(Long parentId);
	
	/**
	 * obtain No包含Button的menu列表
	 */
	List<SysMenu> queryNotButtonList();
	
	/**
	 * queryuser的权限列表
	 */
	List<SysMenu> queryUserList(Long userId);
	
	int deleteBatch(Object[] id);
	
}