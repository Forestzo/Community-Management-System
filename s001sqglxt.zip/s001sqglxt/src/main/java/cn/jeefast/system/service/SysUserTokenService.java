package cn.jeefast.system.service;

import com.baomidou.mybatisplus.service.IService;

import cn.jeefast.common.utils.R;
import cn.jeefast.system.entity.SysUserToken;

/**
 * <p>
 * 系统userToken service类
 * </p>
 *
 */
public interface SysUserTokenService extends IService<SysUserToken> {
	SysUserToken queryByToken(String token);
	
	/**
	 * 生成token
	 * @param userId  userID
	 */
	R createToken(long userId);
}
