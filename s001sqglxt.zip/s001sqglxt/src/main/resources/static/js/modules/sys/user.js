$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + 'sys/user/list',
        datatype: "json",
        colModel: [
            {label: 'UserID', name: 'userId', index: "user_id", width: 45, key: true},
            // { label: '学号/工号', name: 'stadynum', width: 75 },
            {label: 'Username', name: 'username', width: 75},
            {label: 'Name', name: 'realname', width: 75},
            {label: 'Role', name: 'roalArraystr', width: 150},
            { label: 'Community', name: 'deptName', width: 75 },
            {label: 'Phone number', name: 'mobile', width: 80},
            {label: 'Birthday', name: 'birthday', width: 150},
            {label: 'Hometown', name: 'address', width: 150},
            {
                label: 'Personal photos',
                name: 'photopath',
                width: 80,
                align: 'center',
                formatter: function (value, options, row) {
                    return "<img src=" + value + " width='30px' />"
                    // return "<img src=" + "http://localhost:8080/jeefast/upload/20211018/5fcb5290-7ccb-4423-88de-b24670552ff8.png?token=" + token + " width='50px' />"
                }
            },
            {
                label: 'state', name: 'status', width: 80, formatter: function (value, options, row) {
                    return value === 0 ?
                        '<span class="label label-danger">Disable</span>' :
                        '<span class="label label-success">normal</span>';
                }
            },
            // {label: 'create time', name: 'createTime', index: "create_time", width: 90}
        ],
        viewrecords: true,
        height: 385,
        rowNum: 10,
        rowList: [10, 30, 50],
        rownumbers: true,
        rownumWidth: 25,
        autowidth: true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader: {
            root: "page.records",
            page: "page.current",
            total: "page.pages",
            records: "page.total"
        },
        prmNames: {
            page: "page",
            rows: "limit",
            order: "order"
        },
        gridComplete: function () {
            //Hide the scroll bar at the bottom of the grid
            $("#jqGrid").closest(".ui-jqgrid-bdiv").css({"overflow-x": "hidden"});
        }
    });
});

var setting = {
    data: {
        simpleData: {
            enable: true,
            idKey: "deptId",
            pIdKey: "parentId",
            rootPId: -1
        },
        key: {
            url: "nourl"
        }
    }
};
var ztree;

var vm = new Vue({
    el: '#rrapp',
    data: {
        q: {
            username: null
        },
        importModle: true,
        showListuploadsave: true,
        selected: '',
        enclosure: [],
        showList: true,
        showDelect: true,
        title: null,
        roleList: {},
        allFiles: [],
        usertypeAll: [
            {skey: "0", svalue: "student"},
            {skey: "1", svalue: "teacher"},
            {skey: "2", svalue: "administrators"},
            {skey: "3", svalue: "administrators"},
            {skey: "4", svalue: "Repairman"}],
        user: {
            status: 1,
            deptId: null,
            deptName: null,
            roleIdList: [],
            files: [],
        }
    },
    methods: {
        download: function (id) {
            console.log("id)id)id)id)" + id)
            $.get(baseURL + "tMaterialFile/ishSingleFile/" + id, function (r) {
                if (r.code == 0) {
                    if (r.fileName != 'No download file' && r.fileName != 'file does not exist') {
                        var url = baseURL + "tMaterialFile/downFile?id=" + id + "&token=" + token;
                        window.location.href = url;
                    } else {
                        alert(r.fileName)
                    }
                }
            });
        },
        saveFile: function () {
            var value = document.querySelectorAll('*[name="abc"]')
            $("#box").val(value);
            $("#myModalPreachData").modal('hide');
        },
        openPreachData: function () {
            console.log("aaaaaaaaaaaaa")
            $("#fileList").val("");
            $("#myModalPreachData").modal('show');
            vm.selected = "Please select";
        },
        shutdowPreach: function () {
            $("#myModalPreachData").modal('hide');
        },
        importFile: function () {
            if ($("#fileList").val() == null || $("#fileList").val() == "") {
                alert("Please select a specific attachment to upload!");
                return;
            }
            // if (vm.selected == "Please select") {
            // 	alert("Please select密级");
            // 	return;
            // }
            var form = document.getElementById('upload');
            $.ajax({
                url: baseURL + "tMaterialFile/importPsot",
                type: 'post',
                data: new FormData(form),
                processData: false,
                contentType: false,
                dataType: "json",
                success: function (r) {
                    console.log(JSON.stringify(r))
                    if (r.msg == 'false') {
                        alert('You are not qualified to upload this security level');
                        return;
                    }
                    if (r.msg == 'false1') {
                        alert('Secret label program is not started');
                        return;
                    }
                    var obj = new Object();
                    $("#fileList").val("");
                    obj['id'] = r.id;
                    obj['filePath'] = r.path;
                    obj['fileName'] = r.fileName;
                    obj['mbfklj'] = r.mbfklj;
                    vm.allFiles.push(obj);
                    vm.user.files = vm.allFiles;
                    alert("Import  success！");
                },
                error: function () {
                    alert("Import fail!");
                }
            })
        },
        query: function () {
            vm.reload();
        },
        add: function () {
            vm.showList = false;
            vm.title = "add";
            vm.roleList = {};
            vm.user = {deptName: null, deptId: null, status: 1, roleIdList: []};
            vm.allFiles = [];
            vm.user.files = [];
            //obtain role信息
            this.getRoleList();

            vm.getDept();
        },
        getDept: function () {
            //Load Department tree
            $.get(baseURL + "sys/dept/list", function (r) {
                ztree = $.fn.zTree.init($("#deptTree"), setting, r);
                var node = ztree.getNodeByParam("deptId", vm.user.deptId);
                if (node != null) {
                    ztree.selectNode(node);

                    vm.user.deptName = node.name;
                }
            })
        },
        update: function () {
            var userId = getSelectedRow();
            if (userId == null) {
                return;
            }

            vm.showList = false;
            vm.title = "update";

            vm.getUser(userId);
            this.getRoleList();
        },
        del: function () {
            var userIds = getSelectedRows();
            if (userIds == null) {
                return;
            }

            confirm('Are you sure you want to delete the selected record?', function () {
                $.ajax({
                    type: "POST",
                    url: baseURL + "sys/user/delete",
                    contentType: "application/json",
                    data: JSON.stringify(userIds),
                    success: function (r) {
                        if (r.code == 0) {
                            alert('operation success', function () {
                                vm.reload();
                            });
                        } else {
                            alert(r.msg);
                        }
                    }
                });
            });
        },
        saveOrUpdate: function () {
            var url = vm.user.userId == null ? "sys/user/save" : "sys/user/update";
            vm.user.files = vm.allFiles;
            $.ajax({
                type: "POST",
                url: baseURL + url,
                contentType: "application/json",
                data: JSON.stringify(vm.user),
                success: function (r) {
                    if (r.code === 0) {
                        alert('operation success', function () {
                            vm.reload();
                        });
                    } else {
                        alert(r.msg);
                    }
                }
            });
        },
        getUser: function (userId) {
            $.get(baseURL + "sys/user/info/" + userId, function (r) {
                vm.user = r.user;
                vm.allFiles = r.user.files;
                console.log("allFilesallFiles" + JSON.stringify(vm.allFiles))
                console.log("useruseruseruser" + JSON.stringify(r.user))
                vm.user.password = null;

                vm.getDept();
            });
        },
        getRoleList: function () {
            $.get(baseURL + "sys/role/select", function (r) {
                vm.roleList = r.list;
            });
        },
        deptTree: function () {
            layer.open({
                type: 1,
                offset: '50px',
                skin: 'layui-layer-molv',
                title: "Select Department",
                area: ['300px', '450px'],
                shade: 0,
                shadeClose: false,
                content: jQuery("#deptLayer"),
                btn: ['determine', 'cancel'],
                btn1: function (index) {
                    var node = ztree.getSelectedNodes();
                    //Select superior department
                    vm.user.deptId = node[0].deptId;
                    vm.user.deptName = node[0].name;

                    layer.close(index);
                }
            });
        },
        reload: function () {
            vm.showList = true;
            var page = $("#jqGrid").jqGrid('getGridParam', 'page');
            $("#jqGrid").jqGrid('setGridParam', {
                postData: {'username': vm.q.username},
                page: page
            }).trigger("reloadGrid");
        }
    }
});

laydate.render({
    elem: '#birthday', //Specify elements
    // format: 'yyyy-MM-dd HH:mm:ss',
	format: 'yyyy-MM-dd',
    //date time picker
    type: 'datetime',
    done: function (value, date, endDate) {
        vm.user.birthday = value;
    }
});