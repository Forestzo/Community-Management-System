$(function () {
    $("#jqGrid").jqGrid({
        url: baseURL + 'sysServiceadm/list',
        datatype: "json",
        colModel: [
			{ label: 'ID', name: 'id', index: "id", width: 45, key: true },
			{ label: 'Community', name: 'deptName', index: "qcmc", width: 75 },
			{ label: 'service personnel', name: 'username', index: "qcmc", width: 75 },
			{ label: 'servicetitle', name: 'name', index: "qcmc", width: 75 },
			{ label: 'service content', name: 'content', index: "qcmc", width: 75 },
			{ label: 'Is it solved', name: 'type', width: 80,
				formatter: function(value, options, row){
					if(value === "1"){
						return '<span class="label label-success">is</span>';
					}else if(value === "2"){
						return '<span class="label label-success">no</span>';
					}else{
						return '<span class="label label-success">Not selected</span>';
					}
				}
			},
			{ label: 'type', name: 'fl', width: 80,
				formatter: function(value, options, row){
					if(value === "1"){
						return '<span class="label label-success">Parcel query</span>';
					}else if(value === "2"){
						return '<span class="label label-success">Home delivery</span>';
					}else{
						return '<span class="label label-success">Not selected</span>';
					}
				}
			},

        ],
		viewrecords: true,
        height: 385,
        rowNum: 10,
		rowList : [10,30,50],
        rownumbers: true, 
        rownumWidth: 25, 
        autowidth:true,
        multiselect: true,
        pager: "#jqGridPager",
        jsonReader : {
            root: "page.records",
            page: "page.current",
            total: "page.pages",
            records: "page.total"
        },
        prmNames : {
            page:"page", 
            rows:"limit", 
            order: "order"
        },
        gridComplete:function(){
        	//Hide the scroll bar at the bottom of the grid
        	$("#jqGrid").closest(".ui-jqgrid-bdiv").css({ "overflow-x" : "hidden" }); 
        }
    });
});

//Menu tree
var menu_ztree;
var menu_setting = {
	data: {
		simpleData: {
			enable: true,
			idKey: "menuId",
			pIdKey: "parentId",
			rootPId: -1
		},
		key: {
			url:"nourl"
		}
	},
	check:{
		enable:true,
		nocheckInherit:true
	}
};

//Department structure tree
var dept_ztree;
var dept_setting = {
    data: {
        simpleData: {
            enable: true,
            idKey: "deptId",
            pIdKey: "parentId",
            rootPId: -1
        },
        key: {
            url:"nourl"
        }
    }
};

//Data tree
var data_ztree;
var data_setting = {
    data: {
        simpleData: {
            enable: true,
            idKey: "deptId",
            pIdKey: "parentId",
            rootPId: -1
        },
        key: {
            url:"nourl"
        }
    },
    check:{
        enable:true,
        nocheckInherit:true,
        chkboxType:{ "Y" : "", "N" : "" }
    }
};

var vm = new Vue({
	el:'#rrapp',
	data:{
		q:{
			serviceadmName: null
		},
		importModle: true,
		showList: true,
		showDelect: true,
		title:null,
		equipmentList:{},
		allFiles: [],
		users: [],
		types:[{"id":"1","name":"是"},{"id":"2","name":"否"}],
		fls:[{"id":"1","name":"goodsquery"},{"id":"2","name":"provide home delivery service"}],
		serviceadm:{
			id:'',
			qcmc:'',
			bh:'',
			username:'',
			createdate:'',
			enddate:'',
			equipmentIdList:[],
			equipmentId:'',
			serviceadmchild:[],
			deptName:[],
			deptid:'',
			files: [],
		}
	},
	methods: {
		deleteFile: function(id) {
			if(id == null) {
				alert("Please select the file to delete!");
				return;
			}
			vm.deleteFles = {"id":id};
			confirm('Are you sure you want to delete this record?', function(){
				$.ajax({
					type: "POST",
					url: baseURL + "tMaterialFile/deleteByFileId",
					contentType: "application/json",
					data: JSON.stringify(vm.deleteFles),
					success: function(r){
						if(r.code == 0){
							alert('File deleted successfully', function(){
								vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		download: function (id) {
			console.log("id)id)id)id)" + id)
			$.get(baseURL + "tMaterialFile/ishSingleFile/" + id, function (r) {
				if (r.code == 0) {
					if (r.fileName != 'No download file' && r.fileName != 'file does not exist') {
						var url = baseURL + "tMaterialFile/downFile?id=" + id + "&token=" + token;
						window.location.href = url;
					} else {
						alert(r.fileName)
					}
				}
			});
		},
		saveFile: function () {
			var value = document.querySelectorAll('*[name="abc"]')
			$("#box").val(value);
			$("#myModalPreachData").modal('hide');
		},
		openPreachData: function () {
			$("#myModalPreachData").modal('show');
		},
		shutdowPreach: function () {
			$("#myModalPreachData").modal('hide');
		},
		importFile: function () {
			if ($("#fileList").val() == null || $("#fileList").val() == "") {
				alert("Please select a specific attachment to upload!");
				return;
			}
			var form = document.getElementById('upload');
			$.ajax({
				url: baseURL + "tMaterialFile/importPsot",
				type: 'post',
				data: new FormData(form),
				processData: false,
				contentType: false,
				dataType: "json",
				success: function (r) {
					console.log(JSON.stringify(r))
					if (r.msg == 'false') {
						alert('You are not qualified to upload this security level');
						return;
					}
					if (r.msg == 'false1') {
						alert('Secret label program is not started');
						return;
					}
					var obj = new Object();
					$("#fileList").val("");
					obj['id'] = r.id;
					obj['filePath'] = r.path;
					obj['fileName'] = r.fileName;
					obj['mbfklj'] = r.mbfklj;
					vm.allFiles.push(obj);
					vm.serviceadm.files = vm.allFiles;
					alert("Import  success！");
				},
				error: function () {
					alert("Import fail!");
				}
			})
		},
		query: function () {
			vm.reload();
		},
		add: function(){
			vm.showList = false;
			vm.equipmentList = {};
			vm.title = "add";
			vm.serviceadm = {deptName:null, deptId:null};
			vm.getUsersByDeptId('');
			vm.getDept();
		},
		update: function () {
			var id = getSelectedRow();
			if(id == null){
				return ;
			}
			
			vm.showList = false;
            vm.title = "update";
			vm.getUsersByDeptId('');
			vm.getServiceadm(id)
		},
		del: function () {
			var ids = getSelectedRows();
			if(ids == null){
				return ;
			}
			
			confirm('Are you sure you want to delete the selected record?', function(){
				$.ajax({
					type: "POST",
				    url: baseURL + "sysServiceadm/delete",
                    contentType: "application/json",
				    data: JSON.stringify(ids),
				    success: function(r){
						if(r.code == 0){
							alert('operation success', function(){
								vm.reload();
							});
						}else{
							alert(r.msg);
						}
					}
				});
			});
		},
		getUsersByDeptId: function(deptid){
			var param = {deptid:deptid}
			$.ajax({
				type: "POST",
				url: baseURL + "sys/user/getUsersByDeptId",
				contentType: "application/json",
				data: JSON.stringify(param),
				success: function(r){
					if(r.code === 0){
						vm.users = r.users;
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getServiceadm: function(serviceadmId){
            $.get(baseURL + "sysServiceadm/info/"+serviceadmId, function(r){
            	vm.serviceadm = r.serviceadm;
				vm.getDept();
    		});
		},
		saveOrUpdate: function () {
			var url = vm.serviceadm.id == null ? "sysServiceadm/save" : "sysServiceadm/update";
			$.ajax({
				type: "POST",
			    url: baseURL + url,
                contentType: "application/json",
			    data: JSON.stringify(vm.serviceadm),
			    success: function(r){
			    	if(r.code === 0){
						alert('operation success', function(){
							vm.reload();
						});
					}else{
						alert(r.msg);
					}
				}
			});
		},
		getMenuTree: function(id) {
			//Load menu tree
			$.get(baseURL + "sys/menu/list", function(r){
				menu_ztree = $.fn.zTree.init($("#menuTree"), menu_setting, r);
				//Expand all nodes
				menu_ztree.expandAll(true);
				
				if(id != null){
					vm.getServiceadm(id);
				}
			});
	    },
        getDataTree: function(id) {
            //Load menu tree
            $.get(baseURL + "sys/dept/list", function(r){
                data_ztree = $.fn.zTree.init($("#dataTree"), data_setting, r);
                //Expand all nodes
                data_ztree.expandAll(true);
            });
        },

        getDept: function(){
            //Load Department tree
            $.get(baseURL + "sys/dept/list", function(r){
                dept_ztree = $.fn.zTree.init($("#deptTree"), dept_setting, r);
                var node = dept_ztree.getNodeByParam("deptId", vm.serviceadm.deptid);
                if(node != null){
                    dept_ztree.selectNode(node);

                    vm.serviceadm.deptName = node.name;
                }
            })
        },
        deptTree: function(){
            layer.open({
                type: 1,
                offset: '50px',
                skin: 'layui-layer-molv',
                title: "Select Department",
                area: ['300px', '450px'],
                shade: 0,
                shadeClose: false,
                content: jQuery("#deptLayer"),
                btn: ['determine', 'cancel'],
                btn1: function (index) {
                    var node = dept_ztree.getSelectedNodes();
                    //Select superior department
                    vm.serviceadm.deptid = node[0].deptId;
                    vm.serviceadm.deptName = node[0].name;
					vm.getUsersByDeptId(vm.serviceadm.deptid)
                    layer.close(index);
                }
            });
        },
	    reload: function () {
	    	vm.showList = true;
			var page = $("#jqGrid").jqGrid('getGridParam','page');
			$("#jqGrid").jqGrid('setGridParam',{ 
                postData:{'name': vm.q.serviceadmName},
                page:page
            }).trigger("reloadGrid");
		},

	}
});

laydate.render({
	elem: '#faultTime', //Specify elements
	format:'yyyy-MM-dd HH:mm:ss',
	//date time picker
	type: 'datetime',
	done: function(value, date, endDate){
		vm.serviceadm.createdate= value;
	}
});

laydate.render({
	elem: '#enddateTime', //Specify elements
	format:'yyyy-MM-dd HH:mm:ss',
	//date time picker
	type: 'datetime',
	done: function(value, date, endDate){
		vm.serviceadm.enddate= value;
	}
});